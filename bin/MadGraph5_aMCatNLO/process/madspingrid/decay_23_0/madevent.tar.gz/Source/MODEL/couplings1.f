ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c      written by the UFO converter
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      SUBROUTINE COUP1()

      IMPLICIT NONE
      INCLUDE 'model_functions.inc'

      DOUBLE PRECISION PI, ZERO
      PARAMETER  (PI=3.141592653589793D0)
      PARAMETER  (ZERO=0D0)
      INCLUDE 'input.inc'
      INCLUDE 'coupl.inc'
      GC_39 = MDL_COMPLEXI*MDL_G1*MDL_SW
      GC_51 = -(MDL_CW*MDL_COMPLEXI*MDL_GW)/2.000000D+00+(MDL_COMPLEXI
     $ *MDL_G1*MDL_SW)/2.000000D+00
      END
